# Hypothesis_test_Excercise

## Question 1
A F&B manager wants to determine whether there is any significant difference in the diameter of the cutlet between two units. A randomly selected sample of cutlets was collected from both units and measured? Analyze the data and draw inferences at 5% significance level. Please state the assumptions and tests that you carried out to check validity of the assumptions.


     Minitab File : Cutlets.mtw
![image](https://user-images.githubusercontent.com/99672298/158111091-9ce88a4c-fc8c-4d70-b2c5-ae41455a4c15.png)

## Question 2
A F&B manager wants to determine whether there is any significant difference in the diameter of the cutlet between two units. A randomly selected sample of cutlets was collected from both units and measured? Analyze the data and draw inferences at 5% significance level. Please state the assumptions and tests that you carried out to check validity of the assumptions.



![image](https://user-images.githubusercontent.com/99672298/158111114-bd7e872b-bb71-44e9-ae1f-cdd3f113f51a.png)

## Question 3
      Sales of products in four different regions is tabulated for males and females. Find if male-female buyer rations are similar across regions.
![image](https://user-images.githubusercontent.com/99672298/158111131-17759745-9b8c-4701-be65-76bb824b00f5.png)

![image](https://user-images.githubusercontent.com/99672298/158111211-2a7b8953-8e81-4898-8e4f-d751acc18ada.png)

## Question 4
TeleCall uses 4 centers around the globe to process customer order forms. They audit a certain %  of the customer order forms. Any error in order form renders it defective and has to be reworked before processing.  The manager wants to check whether the defective %  varies by centre. Please analyze the data at 5% significance level and help the manager draw appropriate inferences
![image](https://user-images.githubusercontent.com/99672298/158111311-32e403ff-bb8d-4a78-aaa5-c1eaf4972005.png)

